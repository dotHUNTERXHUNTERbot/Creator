import React from 'react';
import { Star, Download, Heart, ShoppingCart } from 'lucide-react';
import { IPAsset } from '../types';

interface AssetCardProps {
  asset: IPAsset;
  onPurchase: (asset: IPAsset) => void;
}

export default function AssetCard({ asset, onPurchase }: AssetCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group border border-gray-100 hover:border-purple-200">
      <div className="relative overflow-hidden">
        <img
          src={asset.thumbnail}
          alt={asset.title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {asset.featured && (
          <div className="absolute top-3 left-3 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-2 py-1 rounded-full text-xs font-semibold">
            Featured
          </div>
        )}
        <button className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:bg-white">
          <Heart className="h-4 w-4 text-gray-600 hover:text-red-500" />
        </button>
      </div>
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
            {asset.category}
          </span>
          <div className="flex items-center space-x-1">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="text-sm text-gray-600">{asset.rating}</span>
            <span className="text-sm text-gray-400">({asset.reviews})</span>
          </div>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-purple-600 transition-colors">
          {asset.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {asset.description}
        </p>
        
        <div className="flex items-center mb-4">
          <img
            src={asset.creator.avatar}
            alt={asset.creator.name}
            className="w-8 h-8 rounded-full object-cover mr-3"
          />
          <div>
            <p className="text-sm font-medium text-gray-900">{asset.creator.name}</p>
            <div className="flex items-center">
              {asset.creator.isVerified && (
                <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
              )}
              <span className="text-xs text-gray-500">Verified Creator</span>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {asset.tags.slice(0, 3).map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs"
            >
              {tag}
            </span>
          ))}
          {asset.tags.length > 3 && (
            <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
              +{asset.tags.length - 3}
            </span>
          )}
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <div className="flex items-center">
              <Download className="h-4 w-4 mr-1" />
              {asset.downloads}
            </div>
            <span>{asset.license}</span>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">${asset.price}</div>
          </div>
        </div>
        
        <button
          onClick={() => onPurchase(asset)}
          className="w-full mt-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white py-3 px-4 rounded-lg font-semibold hover:from-purple-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center space-x-2"
        >
          <ShoppingCart className="h-4 w-4" />
          <span>Purchase Now</span>
        </button>
      </div>
    </div>
  );
}