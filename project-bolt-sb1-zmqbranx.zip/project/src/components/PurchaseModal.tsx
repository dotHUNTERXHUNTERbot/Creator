import React, { useState } from 'react';
import { X, CreditCard, Shield, Download, Star } from 'lucide-react';
import { IPAsset } from '../types';

interface PurchaseModalProps {
  asset: IPAsset | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (asset: IPAsset) => void;
}

export default function PurchaseModal({ asset, isOpen, onClose, onConfirm }: PurchaseModalProps) {
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen || !asset) return null;

  const handlePurchase = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      onConfirm(asset);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block w-full max-w-md my-8 text-left align-middle transition-all transform bg-white shadow-xl rounded-lg">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Complete Purchase</h3>
            <button
              onClick={onClose}
              className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Asset Info */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex space-x-4">
              <img
                src={asset.thumbnail}
                alt={asset.title}
                className="w-16 h-16 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 mb-1">{asset.title}</h4>
                <p className="text-sm text-gray-600 mb-2">by {asset.creator.name}</p>
                <div className="flex items-center space-x-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">{asset.rating}</span>
                  </div>
                  <span className="text-sm text-gray-400">•</span>
                  <span className="text-sm text-gray-600">{asset.downloads} downloads</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-gray-900">${asset.price}</div>
                <div className="text-sm text-gray-500">{asset.license}</div>
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div className="p-6 border-b border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-4">Payment Method</h4>
            <div className="space-y-3">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={paymentMethod === 'card'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="text-purple-600 focus:ring-purple-500"
                />
                <CreditCard className="h-5 w-5 text-gray-400" />
                <span className="text-gray-900">Credit Card</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="radio"
                  name="payment"
                  value="paypal"
                  checked={paymentMethod === 'paypal'}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="text-purple-600 focus:ring-purple-500"
                />
                <div className="w-5 h-5 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">P</div>
                <span className="text-gray-900">PayPal</span>
              </label>
            </div>
          </div>

          {/* Security Info */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-start space-x-3">
              <Shield className="h-5 w-5 text-green-500 mt-0.5" />
              <div>
                <h5 className="font-medium text-gray-900 mb-1">Secure Purchase</h5>
                <p className="text-sm text-gray-600">
                  Your payment is protected by 256-bit SSL encryption. 30-day money-back guarantee.
                </p>
              </div>
            </div>
          </div>

          {/* License Info */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-start space-x-3">
              <Download className="h-5 w-5 text-blue-500 mt-0.5" />
              <div>
                <h5 className="font-medium text-gray-900 mb-1">What You Get</h5>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Instant download access</li>
                  <li>• {asset.license} license</li>
                  <li>• Full source code/files</li>
                  <li>• Documentation & support</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="p-6">
            <div className="flex space-x-3">
              <button
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handlePurchase}
                disabled={isProcessing}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {isProcessing ? 'Processing...' : `Purchase $${asset.price}`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}