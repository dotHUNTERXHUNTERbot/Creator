import React, { useState } from 'react';
import { X, Star, Calendar, Award, TrendingUp, Edit3, Settings, Download } from 'lucide-react';
import { mockUsers, mockAssets } from '../data/mockData';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UserProfile({ isOpen, onClose }: UserProfileProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const user = mockUsers[0]; // Current user
  const userAssets = mockAssets.filter(asset => asset.creator.id === user.id);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={onClose}></div>

        <div className="inline-block w-full max-w-4xl my-8 text-left align-middle transition-all transform bg-white shadow-xl rounded-lg">
          {/* Header */}
          <div className="relative bg-gradient-to-r from-purple-600 to-blue-600 rounded-t-lg p-6">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-white hover:bg-white/20 rounded-lg transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
            
            <div className="flex items-center space-x-6">
              <div className="relative">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white"
                />
                {user.isVerified && (
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                    <Award className="h-3 w-3 text-white" />
                  </div>
                )}
              </div>
              
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-1">{user.name}</h2>
                <p className="text-purple-100 mb-3">{user.bio}</p>
                <div className="flex flex-wrap gap-2">
                  {user.specialties.map((specialty, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-white/20 text-white rounded-full text-sm"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
              
              <button className="px-6 py-2 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                <Edit3 className="h-4 w-4 inline mr-2" />
                Edit Profile
              </button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-4 p-6 border-b border-gray-200">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{user.totalSales}</div>
              <div className="text-sm text-gray-500">Total Sales</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center">
                <Star className="h-5 w-5 text-yellow-400 fill-current mr-1" />
                <span className="text-2xl font-bold text-gray-900">{user.rating}</span>
              </div>
              <div className="text-sm text-gray-500">Rating</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{userAssets.length}</div>
              <div className="text-sm text-gray-500">Assets</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {userAssets.reduce((total, asset) => total + asset.downloads, 0)}
              </div>
              <div className="text-sm text-gray-500">Downloads</div>
            </div>
          </div>

          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'assets', label: 'My Assets' },
                { id: 'purchases', label: 'Purchases' },
                { id: 'analytics', label: 'Analytics' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-purple-500 text-purple-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6 max-h-96 overflow-y-auto">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Recent Activity</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <Download className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Asset purchased</p>
                        <p className="text-xs text-gray-500">Neural Network Architecture - 2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <TrendingUp className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Asset featured</p>
                        <p className="text-xs text-gray-500">Your asset was featured on the homepage - 1 day ago</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Account Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Member Since</label>
                      <p className="text-sm text-gray-900">
                        {new Date(user.joinedDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <p className="text-sm text-gray-900">{user.email}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'assets' && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900">My Assets ({userAssets.length})</h3>
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    Upload New Asset
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userAssets.map(asset => (
                    <div key={asset.id} className="border border-gray-200 rounded-lg p-4">
                      <img
                        src={asset.thumbnail}
                        alt={asset.title}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                      <h4 className="font-semibold text-gray-900 mb-1">{asset.title}</h4>
                      <p className="text-sm text-gray-600 mb-2">${asset.price}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{asset.downloads} downloads</span>
                        <span>{asset.rating}★ ({asset.reviews})</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'purchases' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Purchase History</h3>
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Download className="h-8 w-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500">No purchases yet</p>
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Analytics</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-gradient-to-r from-purple-500 to-blue-500 text-white p-4 rounded-lg">
                    <div className="text-2xl font-bold">$2,340</div>
                    <div className="text-purple-100">Total Earnings</div>
                  </div>
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white p-4 rounded-lg">
                    <div className="text-2xl font-bold">847</div>
                    <div className="text-green-100">Total Downloads</div>
                  </div>
                  <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-4 rounded-lg">
                    <div className="text-2xl font-bold">4.8</div>
                    <div className="text-orange-100">Avg Rating</div>
                  </div>
                  <div className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white p-4 rounded-lg">
                    <div className="text-2xl font-bold">32</div>
                    <div className="text-indigo-100">Assets Sold</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}