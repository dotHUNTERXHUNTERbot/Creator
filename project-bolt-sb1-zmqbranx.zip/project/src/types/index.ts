export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  bio: string;
  specialties: string[];
  rating: number;
  totalSales: number;
  joinedDate: string;
  isVerified: boolean;
}

export interface IPAsset {
  id: string;
  title: string;
  description: string;
  category: string;
  price: number;
  creator: User;
  tags: string[];
  thumbnail: string;
  createdAt: string;
  downloads: number;
  rating: number;
  reviews: number;
  type: 'code' | 'design' | 'content' | 'data' | 'algorithm' | 'model';
  license: string;
  featured: boolean;
}

export interface ChatMessage {
  id: string;
  content: string;
  isBot: boolean;
  timestamp: string;
  userId?: string;
}

export interface ChatBot {
  id: string;
  name: string;
  specialty: string;
  avatar: string;
  description: string;
  isActive: boolean;
}