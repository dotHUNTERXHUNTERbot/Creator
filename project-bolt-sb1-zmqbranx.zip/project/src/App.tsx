import React, { useState } from 'react';
import { IPAsset } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import Marketplace from './components/Marketplace';
import ChatBot from './components/ChatBot';
import UserProfile from './components/UserProfile';
import PurchaseModal from './components/PurchaseModal';

export default function App() {
  const [showChat, setShowChat] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [purchaseAsset, setPurchaseAsset] = useState<IPAsset | null>(null);

  const handlePurchase = (asset: IPAsset) => {
    setPurchaseAsset(asset);
  };

  const handlePurchaseConfirm = (asset: IPAsset) => {
    // Handle successful purchase
    console.log('Purchase confirmed:', asset);
    // You would integrate with your payment processor here
    alert(`Successfully purchased ${asset.title}!`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onShowChat={() => setShowChat(true)}
        onShowProfile={() => setShowProfile(true)}
      />
      
      <Hero />
      
      <Marketplace onPurchase={handlePurchase} />
      
      <ChatBot 
        isOpen={showChat}
        onClose={() => setShowChat(false)}
      />
      
      <UserProfile
        isOpen={showProfile}
        onClose={() => setShowProfile(false)}
      />
      
      <PurchaseModal
        asset={purchaseAsset}
        isOpen={!!purchaseAsset}
        onClose={() => setPurchaseAsset(null)}
        onConfirm={handlePurchaseConfirm}
      />
    </div>
  );
}